#define DO_CALL_TEST4 1
#include "call-test.c"
