#define DO_CALL_TEST3 1
#include "call-test.c"
