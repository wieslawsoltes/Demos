bezctx *
new_bezctx_hittest(double x, double y);

double
bezctx_hittest_report(bezctx *z, int *p_knot_idx);
