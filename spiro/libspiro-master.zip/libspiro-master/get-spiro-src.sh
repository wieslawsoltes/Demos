#!/bin/bash
rm bezctx.c bezctx.h bezctx_intf.h spiro.c spiro.h zmisc.h
wget http://levien.com/garden/ppedit/{bezctx.c,bezctx.h,bezctx_intf.h,spiro.c,spiro.h,zmisc.h}
