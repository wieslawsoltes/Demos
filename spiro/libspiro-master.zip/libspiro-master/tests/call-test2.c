#define DO_CALL_TEST2 1
#include "call-test.c"
